def double_number(a):
    result = a + a
    print(f'Result before doubling: {a}')
    print(f'Result after doubling: {result}')
    return result

def square_number(a):
    result = a * a
    print(f'Result before squaring: {a}')
    print(f'Result after squaring: {result}')
    return result